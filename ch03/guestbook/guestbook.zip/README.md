# guestbook

compile : mvn clean install
Run : mvn jetty:run 
mvn jetty:run -DappName=myapp
